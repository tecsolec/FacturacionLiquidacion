﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace FacturacionLiquidacion
{
    public class datos_fiscales
    {
        public string lista_datos_1 { get; set; }
        public string lista_datos_2 { get; set; }
        public string lista_datos_3 { get; set; }
        public string lista_datos_4 { get; set; }
        public string lista_datos_5 { get; set; }
        public string lista_datos_6 { get; set; }
        public string lista_datos_7 { get; set; }
        public string lista_datos_8 { get; set; }
        public int alfanumerico_1 { get; set; }
        public int alfanumerico_2 { get; set; }
        public int alfanumerico_3 { get; set; }
        public int alfanumerico_4 { get; set; }
        public int alfanumerico_5 { get; set; }
        public double valor_1 { get; set; }
        public double valor_2 { get; set; }
        public double valor_3 { get; set; }
        public double valor_4 { get; set; }
        public double valor_5 { get; set; }
        public DateTime fecha_1 { get; set; }
        public DateTime fecha_2 { get; set; }
        public DateTime fecha_3 { get; set; }
        public DateTime fecha_4 { get; set; }
        public DateTime fecha_5 { get; set; }
        public int booleano_1 { get; set; }
        public int booleano_2 { get; set; }
        public int booleano_3 { get; set; }
        public int booleano_4 { get; set; }
        public int booleano_5 { get; set; }
        public int booleano_6 { get; set; }
        public int booleano_7 { get; set; }
        public string texto_1 { get; set; }
        public string texto_2 { get; set; }
        public string texto_3 { get; set; }
        public datos_fiscales()
        {
            lista_datos_1 = "";
            lista_datos_2 = "";
            lista_datos_3 = "";
            lista_datos_4 = "";
            lista_datos_5 = "";
            lista_datos_6 = "";
            lista_datos_7 = "20";
            lista_datos_8 = "";
            alfanumerico_1 = 0;
            alfanumerico_2 = 0;
            alfanumerico_3 = 0;
            alfanumerico_4 = 0;
            alfanumerico_5 = 0;
            valor_1 = 0;
            valor_2 = 0;
            valor_3 = 0;
            valor_4 = 0;
            valor_5 = 0;
            fecha_1 = DateTime.Now;
            fecha_2 = DateTime.Now;
            fecha_3 = DateTime.Now;
            fecha_4 = DateTime.Now;
            fecha_5 = DateTime.Now;
            booleano_1 = 0;
            booleano_2 = 0;
            booleano_3 = 0;
            booleano_4 = 0;
            booleano_5 = 0;
            booleano_6 = 0;
            booleano_7 = 0;
            texto_1 = "";
            texto_2 = "";
            texto_3 = "";

        }

    }
}
